const Btn = document.getElementById('btn');

Btn.addEventListener("click", function(){
   const inputBtn = document.getElementById('inputBtn').value;

    if(inputBtn == 01){
        const name = "Bangladesh";
        const rank = 10;
        const address = "Dhaka " + 1230;

        document.getElementById('name').innerText = "Name: " + name;
        document.getElementById('rank').innerText = "Rank: " + rank;
        document.getElementById('address').innerText = "Address: " + address;
    }
    else if(inputBtn == 02){
        const name = " Austria";
        const rank = 20;
        const address = "Vienna " + 3000;

        document.getElementById('name').innerText = "Name: " + name;
        document.getElementById('rank').innerText = "Rank: " + rank;
        document.getElementById('address').innerText = "Address " + address;
    }
    else if(inputBtn == 03){
        const name = "Switzerland";
        const rank = 28;
        const address = "Countries " + 2500;

        document.getElementById('name').innerText = "Name: " + name;
        document.getElementById('rank').innerText = "Rank: " + rank;
        document.getElementById('address').innerText = "Address: " + address
    }
    else if(inputBtn == 04){
        const name = "Afghanistan";
        const rank = 30;
        const address = "Kabul " + 2500;

        document.getElementById('name').innerText = "Name: " + name;
        document.getElementById('rank').innerText = "Rank: " + rank;
        document.getElementById('address').innerText = "Address: " + address
    }
    else if(inputBtn == 05){
        const name = " Armenia";
        const rank = 40;
        const address = "Yerevan " + 2500;

        document.getElementById('name').innerText = "Name: " + name;
        document.getElementById('rank').innerText = "Rank: " + rank;
        document.getElementById('address').innerText = "Address: " + address
    }
    else {
        alert("Wrong Number");
    }
});
